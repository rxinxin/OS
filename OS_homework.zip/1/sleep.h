/* sleep.h */
/* Do not change this file */

#ifndef SLEEP_H

#include "kernel.h"
void msleep(uint32_t msecs);

#endif /* !SLEEP_H */

/* dispatch.h */
/* Do not change this file */

#ifndef DISPATCH_H
#define DISPATCH_H

void dispatch(void);

#endif /* !DISPATCH_H */

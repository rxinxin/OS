/* tlb.h */
/* Do not change this file */

#ifndef TLB_H
#include <stdint.h>

void flush_tlb_entry(uint32_t vaddr);
#endif /* !TLB_H */
